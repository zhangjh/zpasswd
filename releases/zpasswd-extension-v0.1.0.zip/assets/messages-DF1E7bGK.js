function r(o){return chrome.runtime.sendMessage(o).then(n=>{if(!n||!n.ok)throw new Error((n==null?void 0:n.error)||"background 调用失败");return n.data})}export{r as b};
